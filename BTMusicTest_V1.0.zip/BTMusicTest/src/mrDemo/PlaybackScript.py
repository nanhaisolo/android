'''
Created on May 13, 2015

@author: Mason.Xie

#1 This Script is used for playing bcak the actions recorded by monkeyrecorder.py script.
#2 Please note that this script needs to use PYTHON interpreter, not monkeyrunner interpreter.
#3 This is a demo only, you can customize your own automation scripts using monkeyrecorder.py, and use this script to play back.

'''

import subprocess
subprocess.Popen(r"D:\sdk\tools\monkeyrunner.bat D:\sdk\tools\monkeyplayback.py D:\workspace1\BTMusicTest\src\mrDemo\SamsungNotee3_BT-on_off.mr",shell=True)
'''
There are 3 parameters:monkeyrunner location, monkeyplayback.py script location, your recorded monkeyrunner XX.mr script location, e.g.,SamsungNotee3_BT-on_off.mr
Execute only once,run out all your XX.mr actions.
'''
