'''
Created on May 11, 2015
@author: Mason.Xie

#1 This Script is used for recording Android Phone actions.
#2 Please note that this script needs to use monkeyrunner interpreter, not PYTHON interpreter.
#3 Please add enough waiting time for buffering to prevent errors when recording actions.
#4  Record steps:execute this script-->record actions-->export file as XX.mr-->done

'''

from com.android.monkeyrunner import MonkeyRunner as mr  
from com.android.monkeyrunner.recorder import MonkeyRecorder as recorder  
  
device = mr.waitForConnection()  
recorder.start(device)  