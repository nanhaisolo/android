'''
Created on May 8, 2015

@author: Mason.Xie

(1)This Script designs basic BT music test cases, including: play/pause, next/previous song, fast forward/rewind, volume+/volume-.
(2)Setup:
    1.Android SDK installed
    2.Cell phone USB driver installed
    3.Python environment and set sdk\tools\monkeyrunner.bat as the Interpreter.
(3) How to execute this script:
    #1. Connect DUT with cell phone via BT
    #2. Connect cell phone and PC via USB
    #3. Change "Music Application launch Activity"
    #4. Unlock screen
    #5. The script controls only cell phone, you must observe DUT,cell phone and console log, to see whether they are consistent and function well
 (4)Music Application launch Activity(this might change via system upgrade):
    Samsung Note3:     'com.sec.android.app.music/.MusicActionTabActivity'
    HTC M8:            'com.htc.music/.browserlayer.MusicBrowserTabActivity'
    HTC ONE X:         'com.htc.music/.browserlayer.MusicBrowserTabActivity'(ff and rewind does not work, not sure why)
    Samsung Note2:     'com.sec.android.app.music/.MusicActionTabActivity'
    Samsung S4:        'com.sec.android.app.music/.MusicActionTabActivity'
    Samsung S5:        'com.sec.android.app.music/.com.samsung.musicplus.MusicMainActivity' (need double check)   
'''

from com.android.monkeyrunner import MonkeyRunner as mr
from com.android.monkeyrunner import MonkeyDevice as md


'''############Connect cell phone. If cannot connect,check,do "adb kill-server" and "adb start-server" and try again###############'''
def connect():
    print "Going to connect phone..."
    global device 
    device=mr.waitForConnection()
    mr.sleep(2)
    if device:
        print "Device connected succesfully!"
    else:
        print "Deviced connected failed! Please check and try again!"

'''##############Change "componentName" according to the phone you use###################'''
def launch_music():
    print "Going to launch music app..."
    componentName='com.sec.android.app.music/.MusicActionTabActivity'
    device.startActivity(component=componentName)
    mr.sleep(2)
    
'''##############Play and pause test, suggest the "n" is odd.###################'''
def play_pause(n):
    print "Going to Play/Pause music..."
    i=1
    while i<=n:
        device.press("KEYCODE_MEDIA_PLAY_PAUSE","DOWN_AND_UP")
        mr.sleep(1) 
        i=i+1
    mr.sleep(1)

def next_previous(n):
    print "Going to Next/Previous song..."
    i=1
    while i<=n:
        device.press("KEYCODE_MEDIA_NEXT","DOWN_AND_UP")
        mr.sleep(1) 
        i=i+1
    j=1
    while j<=n:
        device.press("KEYCODE_MEDIA_PREVIOUS","DOWN_AND_UP")
        mr.sleep(1) 
        j=j+1
    mr.sleep(1)

'''###############suggest set k=20-40 to make it obvious##################'''
def ff_rewind(k):
    print "Going to Fast forward/Rewind song..."
    i=1
    while i<=k:
        device.press("KEYCODE_MEDIA_FAST_FORWARD","DOWN_AND_UP")
        mr.sleep(0.5) 
        i=i+1
    j=1
    while j<=k:
        device.press("KEYCODE_MEDIA_REWIND","DOWN_AND_UP")
        mr.sleep(0.5) 
        j=j+1
    mr.sleep(1)

def vol_add_minus(n):
    print "Going to Vol+/Vol-..."
    mr.sleep(2)
    i=1
    while i<=n:
        device.press("KEYCODE_VOLUME_UP","DOWN_AND_UP")
        mr.sleep(0.5) 
        i=i+1
    j=1
    while j<=n:
        device.press("KEYCODE_VOLUME_DOWN","DOWN_AND_UP")
        mr.sleep(0.5) 
        j=j+1
    mr.sleep(1)
    
if 1:
    connect()
    launch_music()
    play_pause(5)
    next_previous(5)
    ff_rewind(10)
    vol_add_minus(10)
