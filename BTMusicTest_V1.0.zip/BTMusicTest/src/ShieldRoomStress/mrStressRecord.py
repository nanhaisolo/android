'''
Created on May 10, 2015

@author: Mason.Xie

#1 This Script is used for recording BT stress test actions. You need to record in EE shield room to make sure DUT is the unique available BT speaker.
Reason: We use monkeyrunner (x,y) axis to locate element so we have to keep DUT in the same (x,y) every time.

#2 Please note that this script needs to use monkeyrunner interpreter, not PYTHON interpreter.
#3 Please add enough waiting time for buffering to prevent errors when recording actions.
#4  Record steps:execute this script-->record actions-->export file as XX.mr-->done

####Demo:pair and unpair DUT for 100 times(Samsung Note3 and BeatsPillXL)
concept:
Preconditions:Swith on cell phone BT,PC and cell phone connected, DUT and cell phone are not connected.
Before record: monkeyrunner connects cell phone-->go to BT settings.
Reason: we don't want to launch BT Settings Activity every time 

Record:pair DUT and cell phone-->unpair-->export as "SamsungNote3_pair_unpair.mr"
####
'''

from com.android.monkeyrunner import MonkeyRunner as mr  
from com.android.monkeyrunner import MonkeyDevice as md
from com.android.monkeyrunner.recorder import MonkeyRecorder as recorder  
  
device = mr.waitForConnection()  

componentName='com.android.settings/.Settings'
'''
Need to change along with different Android Phones
'''

device.startActivity(component=componentName)
mr.sleep(3)
device.touch(516,752,"DOWN_AND_UP")
'''
Touch to go to BT settings.Need to change along with different Android Phones,use monkeyrecorder.py script to find (x,y).
'''
mr.sleep(1)
recorder.start(device)  


#     componentName='com.sec.android.app.music/.MusicActionTabActivity'
#     device.startActivity(component=componentName)
#     mr.sleep(2)