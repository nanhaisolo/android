'''
Created on May 13, 2015

@author: Mason.Xie

#1 This Script is used for playing bcak the actions recorded by mrStressRecord.py script.
#2 Please note that this script needs to use PYTHON interpreter, not monkeyrunner interpreter.
#3 This is a demo only, you can customize your own automation scripts using monkeyrecorder.py.
#4 Make sure Samsung Note3 is in BT activity and BT is on,disable auto-rotate in cell phone.
#5 For stress test, it is suggested we use a camera to record the LEDS indication/actions/sudio of both DUT and cell phone.
   If error occurs, we rewind the video and check whether it is DUT issue itself or monkeyrunner issue itself.
   Yes,it is a limitation at this moment.
#6 Actually, we might use monkeyrunner "By" lib to locate element by text/id, that could be more accurate,but we cannot open Android View Server if the phone is not rooted.
   As testing cell phones, we should not root any of them.
   Maybe in the future we can figure out a better way.
   
############Cannot ensure this script is very stable, ways might help improve:
#1 locate (x,y) accurately
#2 add correct and enough waiting time

############Need long time to initialize for the first time.
'''

import subprocess
for i in range(100):
    sub=subprocess.Popen(r"D:\sdk\tools\monkeyrunner.bat D:\workspace1\BTMusicTest\src\ShieldRoomStress\mrStressPlay.py D:\workspace1\BTMusicTest\src\ShieldRoomStress\SamsungNote3_pair_unpair.mr",shell=True)
    sub.wait()
    print i

'''
###########Use sub.wait() to make sure we wait for the Popen command finish 1st time then we continue to execute the 2nd time, then 3rd time...
###########
'''
