'''
Author:Mason Xie
TYM0000002122
Aim: for HTCM8 bt connected,randomly click next/previous for 10 times
Verify:Please check the DUT BT status and music order changes when executing this test script.
Precondition: 
1.DUT connected to device
2.HTCM8 screen is awaken
'''
from com.android.monkeyrunner import MonkeyRunner as mr
from com.android.monkeyrunner import MonkeyDevice as md
from com.android.monkeyrunner import MonkeyImage  as mi
import random

def bt_next_and_previous():
    device =mr.waitForConnection()
    if device:
        print "Device connected succesfully!"
    else:
        print "Deviced connected failed!"
        exit(1)
    componentName='com.htc.music/.browserlayer.MusicBrowserTabActivity'
    device.startActivity(component=componentName)
    mr.sleep(1)
    '''------------------choose a song according to X and Y axis----------------'''
    device.touch(516,555,"DOWN_AND_UP")                 
    mr.sleep(1)
    i=1
    
    try:
        while(i<11):
            j=random.randint(0,9)
            print j
            print "this is the %i time" %i
            
            if j>=5:
                device.touch(779,1524,"DOWN_AND_UP")
                i=i+1
                mr.sleep(0.5)   
            else:
                device.touch(293,1516,"DOWN_AND_UP")
                i=i+1
                mr.sleep(0.5)
            if i==11:
                print " 10 times next_and_previous click passed!"
                break
    except:
        print "Failed the next_and_previous test,executed only %i times" %i
if __name__=='__main__':
    bt_next_and_previous()