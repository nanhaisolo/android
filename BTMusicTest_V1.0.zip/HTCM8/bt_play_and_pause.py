'''
Author:Mason Xie
TYM0000002122
Aim: for HTCM8 bt connected, auto choose a song,play and pause music for 10 times
Verify:Please check the DUT BT status and music status after executing this test script.
Precondition: 
1.DUT connected to device
2.HTCM8 screen is awaken
'''
from com.android.monkeyrunner import MonkeyRunner as mr
from com.android.monkeyrunner import MonkeyDevice as md
from com.android.monkeyrunner import MonkeyImage  as mi

def bt_play_and_pause():
    device =mr.waitForConnection()
    if device:
        print "Device connected succesfully!"
    else:
        print "Deviced connected failed!"
        exit(1)
    componentName='com.htc.music/.browserlayer.MusicBrowserTabActivity'
    device.startActivity(component=componentName)
    mr.sleep(1)
    '''------------------choose a song according to X and Y axis----------------'''
    device.touch(516,555,"DOWN_AND_UP")                 
    mr.sleep(1)
    i=1
    try:
        while(i<11):
            print "this is the %i time" %i
            i=i+1
            device.touch(550,1516,"DOWN_AND_UP")
            mr.sleep(0.5)   
            device.touch(550,1516,"DOWN_AND_UP")
            mr.sleep(0.5)
            if i==11:
                print "BT play_and_pause test passed!"
                break
    except:
        print "Failed the play_and_pause test,executed only %i times" %i
if __name__=='__main__':
    bt_play_and_pause()