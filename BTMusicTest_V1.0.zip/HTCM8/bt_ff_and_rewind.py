'''
Author:Mason Xie
TYM0000002122
Aim: for HTCM8 bt connected,randomly press fast forward/rewind(1-30s randomly) on device for 10 times
Verify:Please check the DUT BT status and music progress changes when executing this test script.
Precondition: 
1.DUT connected to device
2.HTCM8 screen is awaken
'''
from com.android.monkeyrunner import MonkeyRunner as mr
from com.android.monkeyrunner import MonkeyDevice as md
from com.android.monkeyrunner import MonkeyImage  as mi
import random

def bt_ff_and_rewind():
    device =mr.waitForConnection()
    if device:
        print "Device connected succesfully!"
    else:
        print "Deviced connected failed!"
        exit(1)
    componentName='com.htc.music/.browserlayer.MusicBrowserTabActivity'
    device.startActivity(component=componentName)
    mr.sleep(1)
    
    i=1
    
    try:
        while(i<11):
            j=random.randint(0,9)
            #print j
            print "this is the %i time" %i
            k=random.randint(1,20) 
            print "this time the long press time is %i seconds" %k 
            if j>=5:
          
                device.touch(779,1524,md.DOWN)
                mr.sleep(k)
                device.touch(779,1524,md.UP)
                i=i+1
                mr.sleep(0.5)   
            else:
                device.touch(293,1516,md.DOWN)
                mr.sleep(k)
                device.touch(293,1516,md.UP)
                i=i+1
                mr.sleep(0.5) 
            if i==11:
                print " 10 times ff_and_rewind click passed!"
                break
    except:
        print "Failed the ff_and_rewind test,executed only %i times" %i
        
if __name__=='__main__':
    bt_ff_and_rewind()