'''
Author:Mason Xie
TYM0000002122
Aim: for HTCM8 bt connected,volume up/down on device for 10 times
Verify:Please check the DUT BT status and music volume changes when executing this test script.
Precondition: 
1.DUT connected to device
2.HTCM8 screen is awaken
3.HTCM8 is playing music
'''
from com.android.monkeyrunner import MonkeyRunner as mr
from com.android.monkeyrunner import MonkeyDevice as md
from com.android.monkeyrunner import MonkeyImage  as mi
import random

def bt_vol_up_and_down():
    device =mr.waitForConnection()
    if device:
        print "Device connected succesfully!"
    else:
        print "Deviced connected failed!"
        exit(1)
    componentName='com.htc.music/.browserlayer.MusicBrowserTabActivity'
    device.startActivity(component=componentName)
    mr.sleep(1)
    
    '''------------------choose a song according to X and Y axis----------------'''
    

    
    i=1
    
    try:
        while(i<11):
            j=random.randint(0,9)
            #print j
            print "this is the %i time" %i
            k=random.randint(1,20) #for HTCM8, the step is 8
            print "%i time the volume change is %i times" %(i,k) 
            if j>=5:
                for n in range(0,k):
                    mr.sleep(1) 
                    device.press("KEYCODE_VOLUME_UP",md.DOWN_AND_UP)
                i=i+1
                mr.sleep(0.5)   
            else:
                for n in range(0,k):
                    mr.sleep(1) 
                    device.press("KEYCODE_VOLUME_DOWN",md.DOWN_AND_UP)
                i=i+1
                mr.sleep(0.5) 
            if i==11:
                print " 10 times vol_up_and_down press passed!"
                break
    except:
        print "Failed the vol_up_and_down test,executed only %i times" %i
        
if __name__=='__main__':
    bt_vol_up_and_down()